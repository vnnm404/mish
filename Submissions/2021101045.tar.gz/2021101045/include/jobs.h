#ifndef _JOBS_H_
#define _JOBS_H_

int sh_jobs(int nargs, char *args[]);

#endif /* _JOBS_H_ */