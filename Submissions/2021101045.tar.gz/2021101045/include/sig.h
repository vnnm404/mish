#ifndef _SIG_H_
#define _SIG_H_

int sh_sig(int nargs, char *args[]);

#endif /* _SIG_H_ */