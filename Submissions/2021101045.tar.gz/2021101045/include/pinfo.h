#ifndef _PINFO_H_
#define _PINFO_H_

int sh_pinfo(int nargs, char *args[]);

#endif /* _PINFO_H_ */