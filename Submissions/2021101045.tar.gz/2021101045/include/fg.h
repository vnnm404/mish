#ifndef _FG_H_
#define _FG_H_

int sh_fg(int nargs, char *args[]);

#endif /* _FG_H_ */