#ifndef _CORE_H_
#define _CORE_H_

int sh_pwd(int nargs, char *args[]);
int sh_cd(int nargs, char *args[]);
int sh_echo(int nargs, char *args[]);
int sh_ls(int nargs, char *args[]);

#endif /* _CORE_H_ */