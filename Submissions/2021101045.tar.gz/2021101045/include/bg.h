#ifndef _BG_H_
#define _BG_H_

int sh_bg(int nargs, char *args[]);

#endif /* _BG_H_ */