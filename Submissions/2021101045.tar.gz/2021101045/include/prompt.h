#ifndef _PROMPT_H_
#define _PROMPT_H_

void input();
void prompt(int exit_stat, long took, char take_input);

#endif /* _PROMPT_H_ */